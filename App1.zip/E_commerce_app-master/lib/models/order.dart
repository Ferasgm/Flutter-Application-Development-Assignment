class Order {
  String documentId;
  int totallPrice;
  String address;
  Order({this.totallPrice, this.address, this.documentId});
}
